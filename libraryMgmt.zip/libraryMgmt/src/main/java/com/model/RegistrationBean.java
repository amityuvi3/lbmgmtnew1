
package com.model;

import java.sql.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;
import javax.validation.constraints.NotEmpty;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Pattern;
import javax.validation.constraints.Size;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.format.annotation.DateTimeFormat;
import org.springframework.stereotype.Component;

@Component
@Entity
public class RegistrationBean {

	@Id
	@NotEmpty(message = "* User Id is required")
	// @Pattern(regexp="(w+@[a-zA-Z_]+?.[a-zA-Z]{2,3})",message="User Id must be
	// a valid email id")
	@Pattern(regexp = "^[_A-Za-z0-9-\\+]+(\\.[_A-Za-z0-9-]+)*@"
			+ "[A-Za-z0-9-]+(\\.[A-Za-z0-9]+)*(\\.[A-Za-z]{2,})$", message = "User Id must be a valid email id")

	private String userId;

	@NotEmpty(message = "* First Name is required")
	private String firstName;
	@NotEmpty(message = "* Last Name is required")
	private String lastName;
	@NotEmpty(message = "* Date is Required")

	// @Pattern(regexp="((0[1-9]|[12]\\d|3[01])/(0[1-9]|1[0-2])/([12]\\d{3}))",message
	// ="* Date required to be in dd/mm/yyyy format")
	private String dOB;

	public String getdOB() {
		return dOB;
	}

	public void setdOB(String dOB) {
		this.dOB = dOB;
	}

	private String gender;

	// @Size(min =10,message="Mobile Number must be of 10 digit")
	@NotEmpty(message = "* Mobile number is required")
	@Pattern(regexp = "^[7-9][0-9]{9}$", message = "Mobile Number must be of 10 digit and start with 7/8/9")
	private String contactNumber;
	private String category;
	@NotEmpty(message = "* Password is required and")
	@Size(min = 8, message = "Password must have at least 8 characters")
	private String password;

	// @Column(columnDefinition = "varchar(255) default 'not approved'")
	private String status = "not approved";

	public String getFirstName() {
		return firstName;
	}

	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}

	public String getLastName() {
		return lastName;
	}

	public void setLastName(String lastName) {
		this.lastName = lastName;
	}

	public String getGender() {
		return gender;
	}

	public void setGender(String gender) {
		this.gender = gender;
	}

	public String getContactNumber() {
		return contactNumber;
	}

	public void setContactNumber(String contactNumber) {
		this.contactNumber = contactNumber;
	}

	public String getCategory() {
		return category;
	}

	public void setCategory(String category) {
		this.category = category;
	}

	public String getUserId() {
		return userId;
	}

	public void setUserId(String userId) {
		this.userId = userId;
	}

	public String getPassword() {
		return password;
	}

	public void setPassword(String password) {
		this.password = password;
	}

	public String getStatus() {
		return status;
	}

	public void setStatus(String status) {
		this.status = status;
	}

}
